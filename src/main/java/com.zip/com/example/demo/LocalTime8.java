package com.example.demo;

import java.time.LocalDate;

public class LocalTime8 {
    public static void main(String arg[]) {
        LocalDate localDate = LocalDate.now();
        System.out.println(localDate);
    }
}
