package com.example.demo;

public class CustomCalculatorImp implements CustomCalculator{
    public static void main(String arg[]){
        CustomCalculatorImp imp=new CustomCalculatorImp();
        imp.addEvenNumbers(1,5,67,6);
    }

    public void test(){
        //addEvenNumbers(1,2,3);
        System.out.println(" inside Test");
        add(intPredicateeven);
        System.out.println(" After Test");
    }

}
