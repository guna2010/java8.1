package com.example.demo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TryWithResource {
    public static void main(String arg[])  {
        BufferedReader reader1 = null;
        try {
            int c=10;
            System.out.println("CCCC");
            //reader1 = new BufferedReader(new FileReader("journaldev.txt"));
        }
        finally{

        }



    }
}
